package com.airmod;

final class PendingRequest {
    private static Request pending;
    private PendingRequest() {}
    static void set(String feature, String state) { pending = new Request(feature, state); }
    static Request take() { Request result = pending; pending = null; return result; }
    static void clear() { pending = null; }
    record Request(String feature, String state) {}
}
