package com.airmod;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.Locale;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class AirModClient implements ClientModInitializer {
    private static KeyMapping voiceKey;

    @Override
    public void onInitializeClient() {
        voiceKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.airmod.voice",
            InputConstants.Type.KEYSYM,
            InputConstants.KEY_G,
            "category.airmod.controls"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (voiceKey.consumeClick()) {
                if (client.player != null) {
                    // PojavLauncher can show the Android keyboard for chat. Tap the keyboard's
                    // microphone to dictate into the prefilled command.
                    client.setScreen(new ChatScreen("/airmod voice "));
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
            literal("airmod")
                .then(literal("help").executes(ctx -> {
                    say(ctx.getSource(), "Натисни G, потім натисни мікрофон клавіатури й скажи команду.");
                    say(ctx.getSource(), "Приклади: «увімкни X-Ray», «вимкни AutoFish», «покажи мої моди».");
                    say(ctx.getSource(), "Команди: /airmod mods | /airmod confirm | /airmod cancel");
                    return 1;
                }))
                .then(literal("mods").executes(ctx -> {
                    say(ctx.getSource(), "Установлені Fabric-моди:");
                    int count = 0;
                    for (ModContainer mod : FabricLoader.getInstance().getAllMods()) {
                        say(ctx.getSource(), mod.getMetadata().getId() + " — " + mod.getMetadata().getName());
                        count++;
                    }
                    say(ctx.getSource(), "Усього: " + count + ". Не кожен мод можна перемикати під час гри.");
                    return 1;
                }))
                .then(literal("voice").then(argument("phrase", StringArgumentType.greedyString()).executes(ctx -> {
                    String phrase = StringArgumentType.getString(ctx, "phrase").toLowerCase(Locale.ROOT).trim();
                    return handleVoicePhrase(ctx.getSource(), phrase);
                })))
                .then(literal("confirm").executes(ctx -> confirm(ctx.getSource())))
                .then(literal("cancel").executes(ctx -> {
                    PendingRequest.clear();
                    say(ctx.getSource(), "Запит скасовано. Нічого не змінено.");
                    return 1;
                }))
        ));
    }

    private static int handleVoicePhrase(FabricClientCommandSource source, String phrase) {
        if (phrase.contains("підтвердж") || phrase.contains("так, виконай") || phrase.equals("так")) {
            return confirm(source);
        }
        if (phrase.contains("скасуй") || phrase.contains("відміна") || phrase.contains("скасувати")) {
            PendingRequest.clear();
            say(source, "Запит скасовано. Нічого не змінено.");
            return 1;
        }
        if (phrase.contains("покажи") && (phrase.contains("мод") || phrase.contains("встановлен"))) {
            say(source, "Щоб побачити всі моди, введи /airmod mods.");
            say(source, "Голосовий запит розпізнано; повний список можна вивести окремою командою.");
            return 1;
        }

        boolean on = phrase.contains("увімк") || phrase.contains("включ") || phrase.contains("запуст");
        boolean off = phrase.contains("вимк") || phrase.contains("відключ") || phrase.contains("зупин");
        String feature = null;
        if (phrase.contains("x-ray") || phrase.contains("xray") || phrase.contains("ікс рей") || phrase.contains("іксрей")) {
            feature = "xray";
        } else if (phrase.contains("autofish") || phrase.contains("auto fish") || phrase.contains("автофіш") || phrase.contains("авто фіш") || phrase.contains("авто фішер")) {
            feature = "autofish";
        } else if (phrase.contains("killaura") || phrase.contains("kill aura") || phrase.contains("кіл аура") || phrase.contains("кіллаура") || phrase.contains("кіл ауру")) {
            feature = "killaura";
        }

        if (feature == null || on == off) {
            say(source, "Не зрозумів команду: " + phrase);
            say(source, "Приклади: «увімкни X-Ray», «вимкни AutoFish», «увімкни KillAura».");
            return 0;
        }

        PendingRequest.set(feature, on ? "on" : "off");
        say(source, "Потрібне підтвердження: " + feature + " → " + (on ? "увімкнути" : "вимкнути") + ".");
        say(source, "Скажи «підтверджую» через кнопку G або введи /airmod confirm. Для відмови: /airmod cancel.");
        return 1;
    }

    private static int confirm(FabricClientCommandSource source) {
        PendingRequest.Request request = PendingRequest.take();
        if (request == null) {
            say(source, "Немає команди, яка очікує підтвердження.");
            return 0;
        }
        String feature = request.feature();
        boolean found = isTargetModLoaded(feature);
        if (!found) {
            say(source, "Не знайшов установлений мод для команди " + feature + ". Виконай /airmod mods, щоб перевірити список.");
            say(source, "Клавішу не натиснуто.");
            return 0;
        }

        int keyCode = switch (feature) {
            case "xray" -> InputConstants.KEY_X;
            case "autofish" -> 335; // GLFW_KEY_KP_ENTER: цифровий Enter
            case "killaura" -> InputConstants.KEY_J;
            default -> -1;
        };
        if (keyCode < 0) {
            say(source, "Для цієї команди немає налаштованої клавіші.");
            return 0;
        }

        // Click the configured toggle key once. The target mod owns its toggle state.
        KeyMapping.click(InputConstants.Type.KEYSYM.getOrCreate(keyCode));
        String label = switch (feature) {
            case "xray" -> "X-Ray (X)";
            case "autofish" -> "AutoFish (цифровий Enter)";
            case "killaura" -> "KillAura (J)";
            default -> feature;
        };
        say(source, "Команду підтверджено: " + label + ". Клавішу перемикання натиснуто.");
        say(source, "Увага: це лише перемикає стан. AirMod не може гарантувати окремо «увімкнути» або «вимкнути» без інтеграції з конкретним модом.");
        return 1;
    }

    private static boolean isTargetModLoaded(String feature) {
        String[] tokens = switch (feature) {
            case "xray" -> new String[] {"xray", "x-ray", "advanced xray", "advanced-xray"};
            case "autofish" -> new String[] {"autofish", "auto-fisher", "auto fisher", "auto_fisher"};
            case "killaura" -> new String[] {"killaura", "kill-aura", "kill aura"};
            default -> new String[0];
        };
        for (ModContainer mod : FabricLoader.getInstance().getAllMods()) {
            String id = mod.getMetadata().getId().toLowerCase(Locale.ROOT);
            String name = mod.getMetadata().getName().toLowerCase(Locale.ROOT);
            for (String token : tokens) {
                if (id.contains(token.replace(" ", "")) || id.contains(token) || name.contains(token)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static void say(FabricClientCommandSource source, String message) {
        source.sendFeedback(Component.literal("[AirMod] " + message));
    }
}
